% KNN FUNCTION FOR SFS
% DE LA ROSA , E. PATTERN RECOGNITION

function [ErrorRate]=KNN_Classify_SFS(XTRAIN, YTRAIN, XTEST, YTEST)

Traindata = XTRAIN;
Test= XTEST;
Predictions=zeros(length(YTEST),1);


    for j=1:size(Test,1)
    Distances= sqrt(sum((Traindata-repmat(Test(j,:), [size(Traindata,1) 1])).^2,2));
    Distances(:,2)=YTRAIN;

    [minValue, Posit]= min(Distances(:,1));
    Predictions(j)= Distances(Posit,2);
    end
 [confmat a]=confusionmat(Predictions, YTEST);
 ErrorRate = 1- (sum(diag(confmat))/sum(sum(confmat)));
end